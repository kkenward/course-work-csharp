﻿/*
    CIS 297    Assignment 1 Part 1    Due 1-28-2010

    by Karen Kenward

    C# console application in Visual Studio 2008
    to simulate a magic eight ball, 8 sayings are randomly
    selected when user presses ENTER.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CIS297Asgn1_1_kkenward
{
    /* class Program - simulates a magic 8 ball by randomly selecting a fortune
                       from an array of strings when the ENTER Key is pressed.  */
    class Program
    {
        static void Main(string[] args)
        {

            ConsoleKeyInfo cki;         // object for identifing key press info
            Random rand = new Random(); // random number generation

            int numoffortunes = 8;      // number of fortunes

            string[] fortunes = new string[numoffortunes];      // store fortunes in array of strings
            fortunes[0] = "   Something you lost will turn up soon.";
            fortunes[1] = "   Your many hidden talents will become obvious to those around you.";
            fortunes[2] = "   You will stop procrastinating, starting tomorrow.";
            fortunes[3] = "   You will enjoy good health and be surrounded by luxury.";
            fortunes[4] = "   Go confidently in the direction of your dreams.";
            fortunes[5] = "   The best is yet to come.";
            fortunes[6] = "   You will be called to fill a position of high honor and responsibility.";
            fortunes[7] = "   Present your best ideas today to an eager and welcoming audience.";

            Console.WriteLine("");
            Console.WriteLine("Want your fortune told?  Press ENTER to find it.");
   
            cki = Console.ReadKey();        // capture key press

            while (cki.Key == ConsoleKey.Enter)     // continue until other key is pressed
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine(fortunes[rand.Next(numoffortunes)]);      // print random fortune from array
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("Want your fortune told?  Press enter to find it.");
                cki = Console.ReadKey();        // capture key press
            }
        }

    }
}
