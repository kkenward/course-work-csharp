﻿/* CIS 297    Assignment 1 Part 2   Due 2-4-2010
 * filename: Circle.cs
 * by Karen Kenward
 *
 * Class Circle
 * Properties positionX, positionY and radius
 * Static member function TestForOverLap()
 * compares 2 circles using a distance formula
 * to tell if the circles overlap or not.  */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CIS297Asgn1_2_kkenward
{
    /* class Circle - properties positionx, positiony, radius
     *      member function TestForOverLap()
     *      defines a circle by center coordinates and radius
     *      allows testing for overlap of 2 circles  */
    class Circle
    {
        private float positionX;    // center x coordinate
        private float positionY;    // center y coordinate
        private float radius;

        public Circle()         // constructor to set default values
        {
            positionX = 2;
            positionY = 2;
            radius = 2;
        }

        // properties for each private member
        public float PositionX
        {
            get { return positionX; }
            set { positionX = value; }
        }

        public float PositionY
        {
            get { return positionY; }
            set { positionY = value; }
        }

        public float Radius
        {
            get { return radius; }
            set { radius = value; }
        }

        /* member function TestForOverLap receives a circle object
         * uses a distance formula to see if passed in circle overlaps current instance of circle
         * writes result to console
         */
        public void TestForOverLap(Circle othercircle)
        {
            // distance formula  d=squareroot((x1-x2)^2 + (y1-y2)^2)
            double x = (this.PositionX - othercircle.PositionX) * (this.PositionX - othercircle.PositionX);     // x=(x1-x2)*(x1-x2)
            double y = (this.PositionY - othercircle.PositionY) * (this.PositionY - othercircle.PositionY);     // y=(y1-y2)*(y1-y2)
            double distance = Math.Sqrt(x + y);         // square root(x+y)

            // compare distance between centers to sum of both radius'
            if (distance < this.Radius + othercircle.Radius)
                Console.WriteLine("   Circle 1 and 2 overlap.");
            else
                Console.WriteLine("   Circle 1 and 2 do not overlap.");

            Console.WriteLine("");
        }
    }
}
