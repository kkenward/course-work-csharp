﻿/*  CIS 297    Assignment 1 Part 2   Due 2-4-2010
 *  filename: Program.cs
 *  by Karen Kenward
 *
 *  C# console application in Visual Studio 2008
 *  to test for overlapping circles on a 2D grid.
 *  Get user input for center points and radius of
 *  2 circles. Use the distance formula to determine
 *  if the circles overlap.  */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CIS297Asgn1_2_kkenward
{
    /* class Program - gets user info for center points and radius of 2 circles
     *       and calls Circle member function TestForOverLap.  */
    class Program
    {
        static void Main(string[] args)
        {
            Circle circle1 = new Circle();      // declare and instantiate 2 circles
            Circle circle2 = new Circle();
            string point1, point2, rad;         // input strings
            float fpoint1, fpoint2, frad;       // input parsed to floats

            for (int i = 1; i == 1; i = 1)      // infinite loop
            {
                // first circle
                // get user input from console
                Console.WriteLine("");
                Console.WriteLine("Enter information for circle 1 and circle 2.");
                Console.WriteLine("Input center points of circle 1:");
                point1 = Console.ReadLine();
                point2 = Console.ReadLine();
                Console.WriteLine("Input radius for circle 1:");
                rad = Console.ReadLine();
                // convert strings to floats
                float.TryParse(point1, out fpoint1);
                float.TryParse(point2, out fpoint2);
                float.TryParse(rad, out frad);
                // set circle1
                circle1.PositionX = fpoint1;
                circle1.PositionY = fpoint2;
                circle1.Radius = frad;

                // second circle
                // get user input from console
                Console.WriteLine("Input center points of circle 2:");
                point1 = Console.ReadLine();
                point2 = Console.ReadLine();
                Console.WriteLine("Input radius for circle 2:");
                rad = Console.ReadLine();
                // convert strings to floats
                float.TryParse(point1, out fpoint1);
                float.TryParse(point2, out fpoint2);
                float.TryParse(rad, out frad);
                // set circle2
                circle2.PositionX = fpoint1;
                circle2.PositionY = fpoint2;
                circle2.Radius = frad;

                // call circle member function
                circle1.TestForOverLap(circle2);
            }
        }
    }
}
