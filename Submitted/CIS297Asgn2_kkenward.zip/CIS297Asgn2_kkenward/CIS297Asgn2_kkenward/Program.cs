﻿/*  Program.cs
    CIS 297    Assignment 2    Due 2-18-2010

    by Karen Kenward

    C# console application in Visual Studio 2008
    to be designed with Class Designer and using Polymorphism.
    Create generic Robot class, with 2 child classes, Johnny5 and Terminator,
    to calculate functions: SpeedGoingUpRockyMountain, SpeedGoingAcrossFlatPavement,
    DamageFromBullets, DamageFromElectricShock.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CIS297Asgn2_kkenward
{
    /* class Program - Get console input for robot speed and health,
     *          instantiate each type of robot, set properties and call
     *          methods to display results. */
    class Program
    {
        static void Main(string[] args)
        {
            string text;                // input string read from console
            int newHealth = 0;          // generic health
            int newSpeed = 0;           // generic speed
            ConsoleKeyInfo cki;         // object for identifing key press info

            Robot[] arrRobots = new Robot[3];   // array of robots, can hold all types of robots
            arrRobots[0] = new Robot();         // instantiate Robot
            arrRobots[1] = new Johnny5();       // instantiate Johnny5
            arrRobots[2] = new Terminator();    // instantiate Terminator

            do
            {   // do once and continue to loop as long as user presses ENTER
                // Get speed from Console.
                Console.WriteLine();
                Console.WriteLine("Please enter the speed and health of the robots:");
                Console.Write("Enter Speed:  ");
                text = Console.ReadLine();
                // convert string to int
                int.TryParse(text, out newSpeed);

                // Get health from Console.
                Console.Write("Enter Health:  ");
                text = Console.ReadLine();
                // convert string to int
                int.TryParse(text, out newHealth);

                Console.WriteLine();

                foreach (Robot bot in arrRobots)
                {   // set health and speed for each robot in array
                    bot.Health = newHealth;
                    bot.Speed = newSpeed;
                }

                foreach (Robot bot in arrRobots)
                {   // call method SpeedGoingUpRockyMountain for each robot in array
                    int rate = bot.SpeedGoingUpRockyMountain();
                }

                Console.WriteLine();

                foreach (Robot bot in arrRobots)
                {   // call method SpeedGoingAcrossFlatPavement for each robot in array
                    int rate = bot.SpeedGoingAcrossFlatPavement();
                }

                Console.WriteLine();

                foreach (Robot bot in arrRobots)
                {   // call method DamageFromElectricShock for each robot in array
                    int damage = bot.DamageFromElectricShock();
                }

                Console.WriteLine();

                foreach (Robot bot in arrRobots)
                {   // call method DamageFromBullets for each robot in array
                    int damage = bot.DamageFromBullets();
                }

                Console.WriteLine();

                Console.Write("Would you like to run the robot calculator again (Press Enter)? ");
                cki = Console.ReadKey();                // capture key press
            } while (cki.Key == ConsoleKey.Enter);
        }
    }
}
