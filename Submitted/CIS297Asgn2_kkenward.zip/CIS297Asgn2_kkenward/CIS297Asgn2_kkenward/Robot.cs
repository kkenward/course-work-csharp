﻿/*  Robot.cs
    CIS 297    Assignment 2    Due 2-18-2010

    by Karen Kenward

    Generic Robot Class
    Properties: speed, health
    Accessors:  Speed, Health
    Methods:    SpeedGoingUpRockyMountain, SpeedGoingAcrossFlatPavement
        DamageFromElectricShock, DamageFromBullets
*/

using System;
using System.Collections.Generic;
using System.Text;

namespace CIS297Asgn2_kkenward
{
    /// <summary>
    /// Robot is the generic robot class
    /// </summary>
    /// <remarks>Robot is the generic robot class containing properties for health, 
    /// and speed and virtual methods DamageFromBullets, DamageFromElectricShock,
    /// SpeedGoingAcrossFlatPavement, and SpeedGoingUpRockyMountain.</remarks>
    public class Robot
    {
        private int speed;
        private int health;

        public int Speed { get; set; }

        public int Health { get; set; }

        /// <summary>
        /// Reduce Speed by 75%
        /// Can be overriden by child class.
        /// </summary>
        public virtual int SpeedGoingUpRockyMountain()
        {   // calculate reduced speed and write result to console
            int reduceBy = 75;
            int speed = (this.Speed * (100 - reduceBy)) / 100;
            Console.WriteLine("Generic Robot's speed going up a rocky mountain is " + speed);
            return speed;
        }

        /// <summary>
        /// Reduce Speed by 5%
        /// Can be overriden by child class.
        /// </summary>
        public virtual int SpeedGoingAcrossFlatPavement()
        {   // calculate reduced speed and write result to console
            int reduceBy = 5;
            int speed = (this.Speed * (100 - reduceBy)) / 100;
            Console.WriteLine("Generic Robot's speed going across pavement is " + speed);
            return speed;
        }

        /// <summary>
        /// Reduce Health by 70%
        /// Can be overriden by child class.
        /// </summary>
        public virtual int DamageFromBullets()
        {   // calculate reduced health and write result to console
            int reduceBy = 70;
            int health = (this.Speed * (100 - reduceBy)) / 100;
            Console.WriteLine("Generic Robot's health (after bullet impact) is " + health);
            return health;
        }

        /// <summary>
        /// Reduce Health by 15%
        /// Can be overriden by child class.
        /// </summary>
        public virtual int DamageFromElectricShock()
        {   // calculate reduced health and write result to console
            int reduceBy = 15;
            int health = (this.Speed * (100 - reduceBy)) / 100;
            Console.WriteLine("Generic Robot's health (after shock) is " + health);
            return health;
        }
    }
}
