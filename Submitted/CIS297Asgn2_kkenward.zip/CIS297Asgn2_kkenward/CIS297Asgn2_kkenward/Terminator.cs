﻿/*  Terminator.cs
    CIS 297    Assignment 2    Due 2-18-2010

    by Karen Kenward

    Terminator Class
    Inherits from Robot Class
    Overrides Methods:    SpeedGoingUpRockyMountain, SpeedGoingAcrossFlatPavement
        DamageFromElectricShock, DamageFromBullets
*/

using System;
using System.Collections.Generic;
using System.Text;

namespace CIS297Asgn2_kkenward
{
    /// <summary>
    /// Terminator class inherits from Robot class.
    /// </summary>
    /// <remarks>Terminator is a class that inherits from Robot class and overrides
    /// the methods DamageFromBullets, DamageFromElectricShock, SpeedGoingAcrossFlatPavement, 
    /// and SpeedGoingUpRockyMountain.</remarks>
    public class Terminator : Robot
    {

        /// <summary>
        /// Reduce Speed by 5%
        /// </summary>
        public override int SpeedGoingAcrossFlatPavement()
        {   // calculate reduced speed and write result to console
            int reduceBy = 5;
            int speed = (this.Speed * (100 - reduceBy)) / 100;
            Console.WriteLine("Terminator's speed going across pavement is " + speed);
            return speed;
        }

        /// <summary>
        /// Reduce Health by 25%
        /// </summary>
        public override int DamageFromBullets()
        {   // calculate reduced health and write result to console
            int reduceBy = 25;
            int health = (this.Speed * (100 - reduceBy)) / 100;
            Console.WriteLine("Terminator's health (after bullet impact) is " + health);
            return health;
        }

        /// <summary>
        /// Reduce Health by 15%
        /// </summary>
        public override int DamageFromElectricShock()
        {   // calculate reduced health and write result to console
            int reduceBy = 15;
            int health = (this.Speed * (100 - reduceBy)) / 100;
            Console.WriteLine("Terminator's health (after shock) is " + health);
            return health;
        }

        /// <summary>
        /// Reduce Speed by 10%
        /// </summary>
        public override int SpeedGoingUpRockyMountain()
        {   // calculate reduced speed and write result to console
            int reduceBy = 10;
            int speed = (this.Speed * (100 - reduceBy)) / 100;
            Console.WriteLine("Terminator's speed going up a rocky mountain is " + speed);
            return speed;
        }
    }
}
