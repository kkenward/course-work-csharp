﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;

namespace CIS297Asgn3_kkenward
{
    /// <summary>
    /// class: Bomb
    /// propeties: bombCount, texture, blastTexture, blastScale, scorchTexture, position, spriteRectangle,
    ///             droppedAt, BOMBLIFE, BOMBWIDTH, BOMBHEIGHT, drop, explosion
    /// constructor: Bomb(Game, Texture2D)
    /// method: Update(GameTime), ExplodeBomb(), Draw(GameTime), PlaceBomb(Rectangle)
    /// 
    /// This is a game component that implements DrawableGameComponent.
    /// Bomb places, updates, draws and explodes itself.
    /// </summary>
    class Bomb : Microsoft.Xna.Framework.DrawableGameComponent
    {
        public static int bombCount = 10;           // Number of bombs available

        protected Texture2D texture;                // bomb image
        protected Texture2D blastTexture;           // blast image
        protected Texture2D scorchTexture;          // scorch mark image

        protected Vector2 position;                 // coordinate of bomb
        protected Rectangle spriteRectangle;        // bounding rectangle

        public int droppedAt = 0;                   // gametime when bomb was dropped
        protected float blastScale = 1f;            // scale of blast

        protected const int BOMBLIFE = 15000;       // 15000 milliseconds = 15 seconds
        protected const int BOMBWIDTH = 30;         // width within texture
        protected const int BOMBHEIGHT = 26;        // height within texture

        public static SoundEffect drop;             // sound when dropped
        public static SoundEffect explosion;        // sound when exploding


        // constructor function, initialize properties of a Bomb
        /// <summary>
        /// Bomb Constructor
        /// </summary>
        /// <param name="game">Current instance of the game.</param>
        /// <param name="newTexture">Bomb image.</param>
        /// <param name="newBlast">Blast image.</param>
        /// <param name="newScorch">Scorch mark image.</param>
        public Bomb(Game game, ref Texture2D newTexture, ref Texture2D newBlast, ref Texture2D newScorch)
            : base(game)
        {
            position = new Vector2(0,0);
            texture = newTexture;
            blastTexture = newBlast;
            scorchTexture = newScorch;

            // can get specific area of texture with this rectangle
            spriteRectangle = new Rectangle(35, 35, BOMBWIDTH, BOMBHEIGHT);
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// Check droppedAt to determine status of bomb.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            if (droppedAt > 0)              // bomb has been dropped
            {
                if (droppedAt + BOMBLIFE < System.Environment.TickCount)    // time to explode
                    this.ExplodeBomb();
            }
            else if (droppedAt < 0)         // still exploding
            {
                droppedAt++;
                blastScale += .25f;         // increase scale of explosion
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// Begins the explosion sequence.
        /// </summary>
        public void ExplodeBomb()
        {
            explosion.Play();               // play sound effect
            droppedAt = -20;                // will increase for 20 updates
            blastScale = 1f;
            bombCount++;                    // bomb available to drop again
        }

        /// <summary>
        /// Allows the game component to draw itself.
        /// Uses updated droppedAt to determine texture to draw, draws at level 0.5, uses scale for blast.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Draw(GameTime gameTime)
        {
            // get the current sprite batch
            SpriteBatch sBatch = (SpriteBatch)Game.Services.GetService(typeof(SpriteBatch));

            if (droppedAt > 0)              // draw bomb
            {
                sBatch.Draw(texture, new Rectangle((int)position.X, (int)position.Y, BOMBWIDTH, BOMBHEIGHT),
                            spriteRectangle, Color.White, 0f, new Vector2(10f, 10f), SpriteEffects.None, 0.5f);
            }
            else if (droppedAt < -10)       // draw blast using blastScale for 10 updates
            {
                sBatch.Draw(blastTexture, new Vector2(position.X, position.Y),
                            spriteRectangle, Color.White, 0f, new Vector2(10f, 10f), blastScale, SpriteEffects.None, 0.5f);
            }
            else if (droppedAt < 0)         // draw scorch mark for 10 updates
            {
                sBatch.Draw(scorchTexture, new Rectangle((int)position.X, (int)position.Y, BOMBWIDTH, BOMBHEIGHT),
                            spriteRectangle, Color.White, 0f, new Vector2(10f, 10f), SpriteEffects.None, 0.5f);
            }

            base.Draw(gameTime);
        }

        /// <summary>
        /// Places bomb based on position of spaceship.
        /// </summary>
        /// <param name="shipsRec">Rectangle denoting position of spaceship when dropped.</param>
        public void PlaceBomb(Rectangle shipsRec)
        {
            if ((bombCount > 0) && (droppedAt == 0))        // make sure bomb is available
            {
                position = new Vector2(shipsRec.Center.X, shipsRec.Center.Y);
                droppedAt = System.Environment.TickCount;   // time of drop
                bombCount--;                // decrease bombcount
                drop.Play();                // play sound effect
            }
        }
   }
}
