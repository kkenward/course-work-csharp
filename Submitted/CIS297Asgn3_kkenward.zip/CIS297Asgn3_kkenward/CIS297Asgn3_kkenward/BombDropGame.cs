/*  CIS297 C#    Assignment #3
 *  Due: 3/25/2010
 *  by Karen Kenward
 * 
 *  Create a game application for a spaceship which user can 'fly' over a map and drop as many as 10 bombs.
 *  Bombs take 15 seconds to explode before being available to drop again. Load textures, font and sound effects.
 *  Can get user input from XBox 360 Gamepad/Keyboard.  Left thumbstick/arrow keys moves ship. "A"/"B" drops bombs.
 *  Right trigger/"SPACE" rotates ship. "BACK"/"ESC" exits game.
 */
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CIS297Asgn3_kkenward
{
    /// <summary>
    /// class: BombDropGame
    /// propeties: graphics, spriteBatch, gameFont, myMap, shipTexture, mySpaceShip, bombTexture,
    ///             bombArray[], blastTexture, scorchTexture, prevGamepadState, prevKeyboardState, exit, CREDITTIME
    /// constructor: BombDropGame()
    /// method: Initialize(), LoadContent(), UnloadContent(), Start(), Update(GameTime), Draw(GameTime)
    /// 
    /// This is the main type for the game
    /// </summary>
    public class BombDropGame : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        //Font object
        private SpriteFont gameFont;

        // map object
        private Map myMap;

        // ship object
        private Texture2D shipTexture;
        private SpaceShip mySpaceShip;

        // bomb object
        private Texture2D bombTexture;
        Bomb[] bombArray = new Bomb[10];                        // array of 10 bombs
        private Texture2D blastTexture;
        private Texture2D scorchTexture;

        // input states
        private GamePadState prevGamepadState;
        private KeyboardState prevKeyboardState;

        private int exit = 0;                                   // timestamp when user presses BACK or ESC
        private const int CREDITTIME = 3000;                    // 3 seconds for viewing credits

        /// <summary>
        /// BombDropGame Constructor
        /// </summary>
        public BombDropGame()
        {   
            // get the graphicsDeviceManager
            graphics = new GraphicsDeviceManager(this);

            // set screen buffer size
            graphics.PreferredBackBufferWidth = 771;
            graphics.PreferredBackBufferHeight = 640;

            // root directory for audio, image, font folders
            Content.RootDirectory = "Content";
       }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of the content.
        /// </summary>
        protected override void LoadContent()
        {
            // load 2D textures for map, ship, bomb
            myMap = new Map(Content.Load<Texture2D>("Images/map2"),  
                            new Rectangle(0, 0, graphics.GraphicsDevice.DisplayMode.Width,
                            graphics.GraphicsDevice.DisplayMode.Height));

            shipTexture = Content.Load<Texture2D>("Images/ship");

            bombTexture = Content.Load<Texture2D>("Images/bomb");
            blastTexture = Content.Load<Texture2D>("Images/blast");
            scorchTexture = Content.Load<Texture2D>("Images/scorch");
            
            // Create a new SpriteBatch service, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            Services.AddService(typeof(SpriteBatch), spriteBatch);

            // load audio
            Bomb.drop = Content.Load<SoundEffect>("Audio/drop");
            Bomb.explosion = Content.Load<SoundEffect>("Audio/boom");

            // load font
            gameFont = Content.Load<SpriteFont>("Fonts/SpriteFont1");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // unload 2D textures for map, ship, bomb
            myMap.texture.Dispose();
            shipTexture.Dispose();
            bombTexture.Dispose();
            blastTexture.Dispose();
            scorchTexture.Dispose();

            // unload audio
            Bomb.drop.Dispose();
            Bomb.explosion.Dispose();
        }

        /// <summary>
        /// Called from Update() at the beginning of the game.
        /// </summary>
        private void Start()
        {
            if (mySpaceShip == null)
            {   // create instance of ship
                mySpaceShip = new SpaceShip(this, ref shipTexture);
                // add as game component
                Components.Add(mySpaceShip);

                // create array of 10 bombs
                for (int i = 0; i < 10; i++)
                {
                    bombArray[i] = new Bomb(this, ref bombTexture, ref blastTexture, ref scorchTexture);
                    // add each bomb as game component
                    Components.Add(bombArray[i]);
                }
            }

            // position ship
            mySpaceShip.PutInStartPosition();

            // initialize gamepad and keyboard states
            prevKeyboardState = Keyboard.GetState();
            prevGamepadState = GamePad.GetState(PlayerIndex.One);
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // get current state of gamepad and keyboard
            GamePadState currGamepadState = GamePad.GetState(PlayerIndex.One);
            KeyboardState currKeyboardState = Keyboard.GetState();

            // Allows the game to exit
            if ((currGamepadState.Buttons.Back == ButtonState.Pressed) ||
                (currKeyboardState.IsKeyDown(Keys.Escape)))
            {
                exit = System.Environment.TickCount;
            }
            // Pause for credits
            if ((exit > 0) && (System.Environment.TickCount - exit > CREDITTIME))
            {
                this.Exit();
            }

            // beginning of game
            if (mySpaceShip == null)
            {
                Start();
            }

            // rotate ship
            if (currGamepadState.Triggers.Right > 0)                // if right trigger, rotate
                mySpaceShip.rotation += currGamepadState.Triggers.Right;
            else if (currKeyboardState.IsKeyDown(Keys.Space))       // if spacebar, rotate
                mySpaceShip.rotation += 1f;
            else                                                    // else stop rotating
                mySpaceShip.rotation = 0;

            // if gamepad A or keyboard B, call ship bomb drop method
            if (((currGamepadState.Buttons.A == ButtonState.Pressed) &&
                (prevGamepadState.Buttons.A == ButtonState.Released)) ||
                (currKeyboardState.IsKeyDown(Keys.B) &&
                prevKeyboardState.IsKeyUp(Keys.B)))
            {
                if (Bomb.bombCount > 0)
                {   // search bombArray for an available bomb
                    int i = 0;
                    while (bombArray[i].droppedAt > 0)
                    {
                        i++;
                    }
                    if (i < 10)
                    {   // call PlaceBomb() with current bounds of ship
                        bombArray[i].PlaceBomb(mySpaceShip.GetBounds());
                    }
                }
            }

            // save current gamepad and keyboard states for next update
            prevGamepadState = currGamepadState;
            prevKeyboardState = currKeyboardState;

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// Draw bomb count and credit text at level 0.9. Calls Map.Draw().
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.Navy);

            spriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.FrontToBack, SaveStateMode.None);

            if (exit > 0)
            {   // before exiting, draw credit info (my boys, ages 12 & 8, made pngs and wavs)
                spriteBatch.DrawString(gameFont, "Credits", new Vector2(230f, 150f),
                                        Color.Gold, 0f, new Vector2(0, 0), 1f, SpriteEffects.None, 0.9f);
                spriteBatch.DrawString(gameFont, "Artwork and Sound Effects By", new Vector2(230f, 190f),
                                        Color.Gold, 0f, new Vector2(0, 0), 1f, SpriteEffects.None, 0.9f);
                spriteBatch.DrawString(gameFont, "~ Quinn Kenward", new Vector2(260f, 230f),
                                        Color.Gold, 0f, new Vector2(0, 0), 1f, SpriteEffects.None, 0.9f);
                spriteBatch.DrawString(gameFont, "~ Nathan Kenward", new Vector2(260f, 260f),
                                        Color.Gold, 0f, new Vector2(0, 0), 1f, SpriteEffects.None, 0.9f);
            }
            else
            {   // draw bomb counter
                spriteBatch.DrawString(gameFont, "Remaining Bombs: " + Bomb.bombCount.ToString(), new Vector2(15f, 15f),
                                        Color.Cyan, 0f, new Vector2(0, 0), 1f, SpriteEffects.None, 0.9f);

                // call draw method for map
                myMap.Draw(spriteBatch);
            }

            base.Draw(gameTime);

            spriteBatch.End();
        }
    }
}
