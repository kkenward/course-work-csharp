﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace CIS297Asgn3_kkenward
{
    /// <summary>
    /// class: Map
    /// propeties: texture, spriteRectangle
    /// constructor: Map(Texture2D, Rectangle)
    /// method: Draw(SpriteBatch)
    /// 
    /// This is the background map.
    /// </summary>
    class Map
    {
        // declare properties of map class
        public Texture2D texture;                   // map image
        protected Rectangle spriteRectangle;        // bounding rectangle

        /// <summary>
        /// Map Constructor
        /// </summary>
        /// <param name="newTexture">Map image.</param>
        /// <param name="boundingRec">Defines size of the map.</param>
        public Map(Texture2D newTexture, Rectangle boundingRec)
        {
            texture = newTexture;
            spriteRectangle = boundingRec;
        }

        /// <summary>
        /// Draw method
        /// Draws map at the lowest level, source and destination rectangles are same size
        /// </summary>
        /// <param name="spriteBatch">Sprite group settings</param>
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, spriteRectangle, spriteRectangle, Color.White, 0f,
                                new Vector2(0, 0), SpriteEffects.None, 0.1f); 
        }
    }
}
