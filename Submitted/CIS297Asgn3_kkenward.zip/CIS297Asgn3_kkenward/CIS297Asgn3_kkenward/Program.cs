using System;

namespace CIS297Asgn3_kkenward
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            using (BombDropGame game = new BombDropGame())
            {
                game.Run();
            }
        }
    }
}

