using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace CIS297Asgn3_kkenward
{
    /// <summary>
    /// class: SpaceShip
    /// propeties: texture, spriteRectangle, position, rotation, SHIPWIDTH, SHIPHEIGHT, screenBounds
    /// constructor: SpaceShip(Game, Texture2D)
    /// method: Initialize(), PutInStartPosition(), Update(GameTime), Draw(GameTime), GetBounds()
    /// 
    /// This is a game component that implements DrawableGameComponent.
    /// SpaceShip updates itself with input from Keyboard or XBox360 Controller and draws itself.
    /// </summary>
    public class SpaceShip : Microsoft.Xna.Framework.DrawableGameComponent
    {
        protected Texture2D texture;            // spaceship image
        protected Rectangle spriteRectangle;    // bounding rectangle
        protected Vector2 position;             // coordinate position of center of spaceship
        public float rotation = 0f;             // rate of spinning

        protected const int SHIPWIDTH = 76;     // width within texture
        protected const int SHIPHEIGHT = 76;    // height within texture

        protected Rectangle screenBounds;       // size of the screen

        /// <summary>
        /// SpaceShip Constructor
        /// </summary>
        /// <param name="game">Instance of current game.</param>
        /// <param name="theTexture">Sprite image.</param>
        public SpaceShip(Game game, ref Texture2D theTexture)
            : base(game)
        {
            texture = theTexture;
            position = new Vector2();

            // can get specific area of texture with this rectangle
            spriteRectangle = new Rectangle(12, 12, SHIPWIDTH, SHIPHEIGHT);

            screenBounds = new Rectangle(0, 0,
                Game.Window.ClientBounds.Width,
                Game.Window.ClientBounds.Height);
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            base.Initialize();
        }

        /// <summary>
        /// Places spaceship in center of screen.
        /// </summary>
        public void PutInStartPosition()
        {
            position.X = (float)(screenBounds.Width / 2);
            position.Y = (float)(screenBounds.Height / 2);
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// Changes position based on input.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // if input from gamepad left thumbstick, get new position of spaceship
            GamePadState gamePadStatus = GamePad.GetState(PlayerIndex.One);
            position.Y += (float)((gamePadStatus.ThumbSticks.Left.Y * 3) * -2);
            position.X += (float)((gamePadStatus.ThumbSticks.Left.X * 3) * 2);

            // if input from keyboard arrow keys, get new position of spaceship
            KeyboardState keyboard = Keyboard.GetState();
            if (keyboard.IsKeyDown(Keys.Up))
            {
                position.Y -= 3;
            }
            if (keyboard.IsKeyDown(Keys.Down))
            {
                position.Y += 3;
            }
            if (keyboard.IsKeyDown(Keys.Left))
            {
                position.X -= 3;
            }
            if (keyboard.IsKeyDown(Keys.Right))
            {
                position.X += 3;
            }

            // since origin is center of ship, adjust for edges
            float halfw = (float)(SHIPWIDTH / 2);
            float halfh = (float)(SHIPHEIGHT / 2);

            // test for borders of screen, adjust position accordingly
            if (position.X < screenBounds.Left + halfw)
            {
                position.X = screenBounds.Left + halfw;
            }
            if (position.X > screenBounds.Width - halfw)
            {
                position.X = screenBounds.Width - halfw;
            }
            if (position.Y < screenBounds.Top + halfh)
            {
                position.Y = screenBounds.Top + halfh;
            }
            if (position.Y > screenBounds.Height - halfh)
            {
                position.Y = screenBounds.Height - halfh;
            }
            
            base.Update(gameTime);
        }

        /// <summary>
        /// Allows the game component to draw itself.
        /// Uses updated position to create destination rectangle, draws at level 0.8, uses rotation.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Draw(GameTime gameTime)
        {
            // get the spritebatch service
            SpriteBatch sBatch = (SpriteBatch)Game.Services.GetService(typeof(SpriteBatch));

            sBatch.Draw(texture, new Rectangle((int)position.X, (int)position.Y, SHIPWIDTH, SHIPHEIGHT), 
                        spriteRectangle, Color.White, rotation, new Vector2(38f, 38f), SpriteEffects.None, 0.8f);

            base.Draw(gameTime);
        }

        /// <summary>
        /// Gets the rectangle of the spaceship based on current position.
        /// </summary>
        /// <returns>Rectangle</returns>
        public Rectangle GetBounds()
        {
            return new Rectangle((int)position.X, (int)position.Y, SHIPWIDTH, SHIPHEIGHT);
        }
    }
}